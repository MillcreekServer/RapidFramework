package io.github.wysohn.rapidframework.main;

import io.github.wysohn.rapidframework.pluginbase.PluginConfig;

public class FakePluginConfig extends PluginConfig {

}
