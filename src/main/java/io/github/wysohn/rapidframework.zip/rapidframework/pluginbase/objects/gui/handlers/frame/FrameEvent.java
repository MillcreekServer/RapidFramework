package io.github.wysohn.rapidframework.pluginbase.objects.gui.handlers.frame;

public interface FrameEvent {

}
