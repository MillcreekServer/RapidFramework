package io.github.wysohn.rapidframework.pluginbase.objects.structure.interfaces.trigger;

public interface Trigger {

}
