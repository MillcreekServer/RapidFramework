package io.github.wysohn.rapidframework.pluginbase.objects;

import java.util.UUID;

public interface PluginEntity {
    UUID getUuid();
}
