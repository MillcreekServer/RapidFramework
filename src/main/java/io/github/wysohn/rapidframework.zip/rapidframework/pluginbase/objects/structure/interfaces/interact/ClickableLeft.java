package io.github.wysohn.rapidframework.pluginbase.objects.structure.interfaces.interact;

public interface ClickableLeft extends Clickable {

}
