package io.github.wysohn.rapidframework.pluginbase.objects.structure.interfaces.interact;

public interface ClickableRight extends Clickable {

}
